<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <MiLista v-bind:msg="mensaje1" v-bind:lista="videojuegos" />
	  <MiLista v-bind:msg="mensaje2" v-bind:lista="musicos" />
  </div>
</template>

<script>
import MiLista from './components/MiLista.vue'

var vj=['Starcraft', 'Conquerors', 'HearthStone', 'Lord of Destruction', 'Starcraft 2'];
var mu=['Evan Craft', 'Marcela Gandara', 'Pablo Olivares', 'Edgar Lira', 'Boanerges'];

export default {
  name: 'app',
  components: {
    MiLista
  },
  data: function(){
    return{
      mensaje1:"Juegos de video que me gustan",
      mensaje2:"Musicos y grupos de música que me gustan",
      videojuegos:vj,
      musicos:mu,
    };
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
